import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Bot, 
  Key, 
  Users, 
  TrendingUp, 
  Clock, 
  CheckCircle, 
  AlertTriangle, 
  XCircle,
  Copy,
  Play,
  RotateCcw,
  Activity,
  FileText,
  LogOut,
  Shield,
  Zap,
  Globe,
  Download,
  ChevronRight,
  Sparkles
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Key as KeyType, UserCooldown, BotLog } from "@shared/schema";

interface Stats {
  totalKeys: number;
  activeKeys: number;
  usersToday: number;
  successRate: number;
}

interface BotStatus {
  online: boolean;
  uptime: string;
}

export default function Dashboard() {
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: stats, isLoading: statsLoading } = useQuery<Stats>({
    queryKey: ["/api/stats"],
    refetchInterval: 30000
  });

  const { data: recentKeys, isLoading: keysLoading } = useQuery<KeyType[]>({
    queryKey: ["/api/keys/recent"],
    refetchInterval: 30000
  });

  const { data: cooldowns, isLoading: cooldownsLoading } = useQuery<UserCooldown[]>({
    queryKey: ["/api/cooldowns"],
    refetchInterval: 30000
  });

  const { data: logs, isLoading: logsLoading } = useQuery<BotLog[]>({
    queryKey: ["/api/logs"],
    refetchInterval: 30000
  });

  const { data: botStatus } = useQuery<BotStatus>({
    queryKey: ["/api/bot/status"],
    refetchInterval: 5000
  });

  const formatTimeLeft = (expiresAt: string) => {
    const now = new Date();
    const expires = new Date(expiresAt);
    const diff = expires.getTime() - now.getTime();
    
    if (diff <= 0) return "Expired";
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    } else {
      return `${minutes}m`;
    }
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  if (statsLoading || keysLoading || cooldownsLoading || logsLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-prism-gradient rounded-full flex items-center justify-center mb-4 mx-auto glow-purple">
            <Bot className="w-8 h-8 text-white" />
          </div>
          <div className="text-prism-text text-lg font-medium">Loading Dashboard...</div>
          <div className="text-prism-muted text-sm mt-2">Connecting to Prism servers</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-prism-text">
      {/* Header */}
      <header className="bg-prism-surface border-b border-prism">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-prism-gradient rounded-xl flex items-center justify-center glow-purple">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-white via-purple-200 to-purple-400 bg-clip-text text-transparent">
                  Prism Dashboard
                </h1>
                <p className="text-prism-muted text-sm">
                  Most Advanced Roblox Executor
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3 px-4 py-2 bg-prism-surface-elevated rounded-lg border border-prism">
                <div className={`w-2 h-2 rounded-full ${botStatus?.online ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
                <div className="text-sm">
                  <span className="font-medium">
                    {botStatus?.online ? 'Online' : 'Offline'}
                  </span>
                  <span className="text-prism-muted ml-2">
                    {botStatus?.uptime || '0s'}
                  </span>
                </div>
              </div>
              
              <Badge className="bg-prism-gradient text-white px-3 py-1 glow-purple">
                <Shield className="w-3 h-3 mr-1" />
                VIP Access
              </Badge>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="gap-2 bg-prism-surface-elevated border-prism hover:bg-prism-surface"
              >
                <LogOut className="h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="bg-gradient-to-br from-prism-surface via-prism-surface to-prism-surface-elevated border-b border-prism">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="text-center">
            <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-white via-purple-200 to-purple-400 bg-clip-text text-transparent">
              Execute Scripts with Prism
            </h2>
            <p className="text-prism-muted text-lg mb-8 max-w-2xl mx-auto">
              The most powerful and reliable Roblox script executor. Fast execution, 
              safe performance, and premium features for the ultimate scripting experience.
            </p>
            <div className="flex items-center justify-center gap-4">
              <Button className="bg-prism-gradient hover:bg-prism-gradient/90 text-white px-8 py-3 text-lg glow-purple">
                <Download className="w-5 h-5 mr-2" />
                Download Prism
              </Button>
              <Button variant="outline" className="border-prism bg-prism-surface-elevated hover:bg-prism-surface px-8 py-3 text-lg">
                <Globe className="w-5 h-5 mr-2" />
                Join Discord
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-prism-surface border border-prism mb-8">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="keys" className="flex items-center gap-2">
              <Key className="w-4 h-4" />
              Key Management
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              User Activity
            </TabsTrigger>
            <TabsTrigger value="logs" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Bot Logs
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-8">
            {/* Why Choose Prism? */}
            <div className="mb-12">
              <h3 className="text-2xl font-bold mb-8 text-center bg-gradient-to-r from-white to-purple-300 bg-clip-text text-transparent">
                Why Choose Prism?
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="bg-prism-surface border-prism card-hover">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-prism-gradient rounded-lg flex items-center justify-center mb-4 glow-purple">
                      <Zap className="w-6 h-6 text-white" />
                    </div>
                    <h4 className="font-semibold text-lg mb-2">Lightning Fast</h4>
                    <p className="text-prism-muted text-sm">
                      Execute scripts instantly with our optimized engine
                    </p>
                  </CardContent>
                </Card>
                
                <Card className="bg-prism-surface border-prism card-hover">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4">
                      <Shield className="w-6 h-6 text-green-400" />
                    </div>
                    <h4 className="font-semibold text-lg mb-2">Safe & Clean</h4>
                    <p className="text-prism-muted text-sm">
                      No malware, no rats - completely safe and trusted software
                    </p>
                  </CardContent>
                </Card>
                
                <Card className="bg-prism-surface border-prism card-hover">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4">
                      <Globe className="w-6 h-6 text-blue-400" />
                    </div>
                    <h4 className="font-semibold text-lg mb-2">Full LuaU Support</h4>
                    <p className="text-prism-muted text-sm">
                      Complete LuaU compatibility with all modern functions
                    </p>
                  </CardContent>
                </Card>
                
                <Card className="bg-prism-surface border-prism card-hover">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center mb-4">
                      <CheckCircle className="w-6 h-6 text-orange-400" />
                    </div>
                    <h4 className="font-semibold text-lg mb-2">100% UNC & sUNC</h4>
                    <p className="text-prism-muted text-sm">
                      Complete Universal Naming Convention and secure UNC support
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card className="bg-prism-surface border-prism card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-prism-muted text-sm">Total Keys</p>
                      <p className="text-3xl font-bold mt-2">{stats?.totalKeys || 0}</p>
                    </div>
                    <div className="w-12 h-12 bg-prism-gradient rounded-lg flex items-center justify-center glow-purple">
                      <Key className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-prism-surface border-prism card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-prism-muted text-sm">Active Keys</p>
                      <p className="text-3xl font-bold mt-2">{stats?.activeKeys || 0}</p>
                    </div>
                    <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                      <CheckCircle className="w-6 h-6 text-green-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-prism-surface border-prism card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-prism-muted text-sm">Users Today</p>
                      <p className="text-3xl font-bold mt-2">{stats?.usersToday || 0}</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                      <Users className="w-6 h-6 text-blue-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-prism-surface border-prism card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-prism-muted text-sm">Success Rate</p>
                      <p className="text-3xl font-bold mt-2">{stats?.successRate || 0}%</p>
                    </div>
                    <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-orange-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card className="bg-prism-surface border-prism">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  {logs?.length ? (
                    <div className="space-y-3">
                      {logs.slice(0, 10).map((log) => (
                        <div key={log.id} className="flex items-center gap-3 p-3 bg-prism-surface-elevated rounded-lg">
                          <div className={`w-2 h-2 rounded-full ${
                            log.level === 'error' ? 'bg-red-400' : 
                            log.level === 'warn' ? 'bg-yellow-400' : 
                            'bg-green-400'
                          }`} />
                          <div className="flex-1">
                            <p className="text-sm">{log.message}</p>
                            <p className="text-xs text-prism-muted">
                              {new Date(log.timestamp).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-prism-muted">
                      No recent activity
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="keys" className="space-y-6">
            <Card className="bg-prism-surface border-prism">
              <CardHeader>
                <CardTitle>Key Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-prism-muted">
                  Key management features coming soon
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card className="bg-prism-surface border-prism">
              <CardHeader>
                <CardTitle>User Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-prism-muted">
                  User activity tracking coming soon
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logs" className="space-y-6">
            <Card className="bg-prism-surface border-prism">
              <CardHeader>
                <CardTitle>Bot Logs</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  {logs?.length ? (
                    <div className="space-y-2">
                      {logs.map((log) => (
                        <div key={log.id} className="flex items-start gap-3 p-3 bg-prism-surface-elevated rounded-lg">
                          <div className={`w-2 h-2 rounded-full mt-2 ${
                            log.level === 'error' ? 'bg-red-400' : 
                            log.level === 'warn' ? 'bg-yellow-400' : 
                            'bg-green-400'
                          }`} />
                          <div className="flex-1">
                            <p className="text-sm">{log.message}</p>
                            <p className="text-xs text-prism-muted">
                              {new Date(log.timestamp).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-prism-muted">
                      No logs available
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}