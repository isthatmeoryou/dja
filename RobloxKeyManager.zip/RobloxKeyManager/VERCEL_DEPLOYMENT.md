# Vercel Deployment Guide

## Prerequisites

1. **Vercel Account**: Sign up at https://vercel.com
2. **GitHub Repository**: Push your code to GitHub
3. **Discord Bot Credentials**: Have your Discord bot tokens ready

## Step-by-Step Deployment

### 1. Push Code to GitHub
```bash
git add .
git commit -m "Ready for Vercel deployment"
git push origin main
```

### 2. Connect to Vercel
1. Go to https://vercel.com/dashboard
2. Click "Add New Project"
3. Import your GitHub repository
4. Select "Discord Key Bot Dashboard" project

### 3. Configure Environment Variables
In Vercel dashboard, go to Project Settings → Environment Variables and add:

**Required Variables:**
- `DATABASE_URL`: Your PostgreSQL connection string
- `DISCORD_TOKEN`: Your Discord bot token
- `DISCORD_CLIENT_ID`: Your Discord application ID
- `DISCORD_CLIENT_SECRET`: Your Discord OAuth client secret
- `SESSION_SECRET`: A random string for session encryption

**Optional Variables:**
- `DISCORD_GUILD_ID`: Restrict bot to specific server
- `DISCORD_CHANNEL_ID`: Restrict commands to specific channel
- `DISCORD_WHITELIST_USERS`: Comma-separated Discord user IDs
- `DISCORD_MONTH_KEY_USERS`: VIP users who can generate month keys

### 4. Deploy
1. Click "Deploy" - Vercel will automatically build and deploy
2. Wait for deployment to complete (2-3 minutes)
3. Get your deployment URL (e.g., `https://your-project.vercel.app`)

### 5. Update Discord OAuth Settings
1. Go to https://discord.com/developers/applications
2. Select your Discord application
3. Go to OAuth2 → Redirects
4. Add your new Vercel URL: `https://your-project.vercel.app/api/callback`
5. Save changes

### 6. Update VIP User List
Update the VIP user IDs in `server/storage.ts` with your Discord IDs:
```typescript
export const VIP_USER_IDS = [
  "1314723072695341059", // Your Discord ID
  "123456789012345678", // Friend 1
  "123456789012345679", // Friend 2
  "123456789012345680"  // Friend 3
];
```

## Important Notes

### Discord Bot Limitations
- **Vercel doesn't support persistent connections**: The Discord bot will NOT run on Vercel
- **Solution**: Deploy the bot separately (e.g., Railway, Render, or Heroku)
- **Dashboard Only**: Vercel will only host the web dashboard, not the Discord bot

### Recommended Architecture
1. **Web Dashboard**: Deploy on Vercel (free tier)
2. **Discord Bot**: Deploy on Railway/Render (separate deployment)
3. **Database**: Use same PostgreSQL for both deployments

### Build Configuration
The project includes:
- `vercel.json`: Vercel deployment configuration
- `build-vercel.js`: Build script for Vercel
- `server/vercel-index.ts`: Serverless function entry point

### Database Setup
Ensure your PostgreSQL database is accessible from Vercel:
- Use Neon, Supabase, or PlanetScale (recommended)
- Make sure connection string includes SSL settings
- Run `npm run db:push` to create tables

### Troubleshooting

**Build Errors:**
- Check that all dependencies are in `package.json`
- Verify TypeScript compilation with `npm run check`

**Runtime Errors:**
- Check environment variables are set correctly
- Verify database connection string format
- Check Vercel function logs in dashboard

**Discord OAuth Issues:**
- Ensure redirect URI matches exactly (including https://)
- Check that all Discord credentials are set as environment variables
- Verify OAuth scopes include "identify"

## Alternative: Full Stack Deployment

For a complete solution including the Discord bot:

1. **Railway**: Deploy entire application including bot
2. **Render**: Free tier supports long-running processes
3. **Heroku**: Supports worker processes for bot

Choose Vercel if you only need the web dashboard, or use Railway/Render for the complete solution.