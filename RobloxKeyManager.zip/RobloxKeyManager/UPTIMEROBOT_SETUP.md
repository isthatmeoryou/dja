# UptimeRobot Setup Guide - Keep Your Discord Bot Running 24/7

## 🤖 Your Discord Bot: Always Online

UptimeRobot will ping your Replit server every 5 minutes to keep your Discord bot "Prism Generator#8177" running 24/7 completely free.

## 🔗 Your Replit App URL

**Your main app URL:** https://052c9442-5e34-4a10-8c9e-cb7a476de68f-00-2528lqba3689v.kirk.replit.dev

## 📋 Step-by-Step Setup

### 1. Create UptimeRobot Account
1. Go to https://uptimerobot.com/
2. Click "Sign Up Free"
3. Create your account (completely free)

### 2. Add Your Monitor
1. Click "Add New Monitor"
2. **Monitor Type:** HTTP(s)
3. **Friendly Name:** Discord Key Bot
4. **URL:** `https://052c9442-5e34-4a10-8c9e-cb7a476de68f-00-2528lqba3689v.kirk.replit.dev/ping`
5. **Monitoring Interval:** 5 minutes (free plan)
6. Click "Create Monitor"

### 3. Optional: Add Health Check Monitor
For more detailed monitoring, add a second monitor:
1. **Monitor Type:** HTTP(s)
2. **Friendly Name:** Discord Bot Health
3. **URL:** `https://052c9442-5e34-4a10-8c9e-cb7a476de68f-00-2528lqba3689v.kirk.replit.dev/api/health`
4. **Monitoring Interval:** 5 minutes
5. Click "Create Monitor"

## ✅ What This Achieves

- **24/7 Uptime:** Your Discord bot stays online continuously
- **Free Monitoring:** UptimeRobot pings every 5 minutes at no cost
- **Auto-Recovery:** If your Replit sleeps, UptimeRobot wakes it up
- **Status Tracking:** Monitor your bot's health and uptime stats
- **Alerts:** Get notified if your bot goes offline

## 🔧 Monitoring Endpoints

Your bot now has two monitoring endpoints:

### `/ping` - Simple Uptime Check
- **URL:** https://052c9442-5e34-4a10-8c9e-cb7a476de68f-00-2528lqba3689v.kirk.replit.dev/ping
- **Response:** `pong`
- **Purpose:** Basic uptime monitoring

### `/api/health` - Detailed Health Check
- **URL:** https://052c9442-5e34-4a10-8c9e-cb7a476de68f-00-2528lqba3689v.kirk.replit.dev/api/health
- **Response:** JSON with bot status and uptime
- **Purpose:** Detailed monitoring with Discord bot status

## 🎯 Benefits

1. **Free 24/7 Hosting:** Your Discord bot runs continuously on Replit
2. **No Monthly Costs:** UptimeRobot free plan provides 5-minute intervals
3. **Automatic Recovery:** Bot automatically restarts if it goes down
4. **VIP Dashboard:** Your Discord OAuth dashboard stays accessible
5. **Slash Commands:** All bot commands work 24/7 (`/generate24key`, `/generate1mkey`, etc.)

## 📊 Current Bot Status

- **Bot Name:** Prism Generator#8177
- **Status:** Online and ready
- **Commands:** `/generate24key`, `/generate1mkey`, `/generateyearkey`, `/generatelifetimekey`, `/setup-logs`
- **VIP Dashboard:** Discord OAuth authentication working
- **Database:** PostgreSQL connected and operational

## 🔄 How It Works

1. UptimeRobot pings your Replit URL every 5 minutes
2. This prevents Replit from sleeping due to inactivity
3. Your Discord bot stays connected to Discord 24/7
4. Users can use slash commands anytime
5. VIP dashboard remains accessible for monitoring

## 🚀 You're All Set!

Once you add the monitor to UptimeRobot, your Discord Key Bot will run 24/7 without any additional setup or monthly costs. Your bot will be as reliable as a paid hosting service, but completely free!

## 📱 Mobile App

UptimeRobot also has mobile apps so you can monitor your bot's status on the go:
- iOS: Search "UptimeRobot" in App Store
- Android: Search "UptimeRobot" in Google Play Store

**Your Discord bot is now production-ready with professional uptime monitoring!**