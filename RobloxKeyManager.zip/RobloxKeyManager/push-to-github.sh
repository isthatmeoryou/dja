#!/bin/bash

echo "🚀 Pushing Discord Key Bot to GitHub..."
echo ""

# Step 1: Check git status
echo "📋 Current git status:"
git status

echo ""
echo "🔄 Adding all files to git..."
git add .

echo ""
echo "📝 Committing changes..."
git commit -m "Discord Key Bot Dashboard - Production ready with Vercel deployment"

echo ""
echo "🌐 Ready to push to GitHub!"
echo ""
echo "⚠️  IMPORTANT: You need to create a GitHub repository first!"
echo "1. Go to: https://github.com/new"
echo "2. Repository name: discord-key-bot-dashboard"
echo "3. Make it Public"
echo "4. DON'T initialize with README"
echo "5. Click 'Create repository'"
echo ""
echo "Then run these commands:"
echo "git remote add origin https://github.com/YOUR_USERNAME/discord-key-bot-dashboard.git"
echo "git push -u origin main"
echo ""
echo "Replace YOUR_USERNAME with your GitHub username!"