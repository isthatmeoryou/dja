#!/usr/bin/env node

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

console.log('🚀 Preparing for Vercel deployment...');

// 1. Build the frontend
console.log('📦 Building frontend...');
try {
  execSync('npx vite build', { stdio: 'inherit' });
  console.log('✅ Frontend build completed');
} catch (error) {
  console.error('❌ Frontend build failed:', error.message);
  process.exit(1);
}

// 2. Verify build files exist
const buildDir = path.join(__dirname, 'dist', 'public');
if (!fs.existsSync(buildDir)) {
  console.error('❌ Build directory not found:', buildDir);
  process.exit(1);
}

// 3. Create .vercelignore if it doesn't exist
const vercelIgnore = path.join(__dirname, '.vercelignore');
if (!fs.existsSync(vercelIgnore)) {
  const ignoreContent = `
# Development files
node_modules
.env*
.replit
replit.nix
.git

# Build artifacts
dist/index.js
server/index.js

# Logs
*.log
bot-logs.json

# OS files
.DS_Store
Thumbs.db
`;
  fs.writeFileSync(vercelIgnore, ignoreContent.trim());
  console.log('✅ Created .vercelignore');
}

// 4. Verify Vercel configuration
const vercelConfig = path.join(__dirname, 'vercel.json');
if (!fs.existsSync(vercelConfig)) {
  console.error('❌ vercel.json not found');
  process.exit(1);
}

// 5. Check server entry point
const serverEntry = path.join(__dirname, 'server', 'vercel-index.ts');
if (!fs.existsSync(serverEntry)) {
  console.error('❌ server/vercel-index.ts not found');
  process.exit(1);
}

console.log('✅ Deployment preparation complete!');
console.log('');
console.log('🔗 Next steps:');
console.log('1. Push your code to GitHub');
console.log('2. Go to https://vercel.com/new');
console.log('3. Import your GitHub repository');
console.log('4. Add environment variables');
console.log('5. Deploy!');
console.log('');
console.log('Required environment variables:');
console.log('- DATABASE_URL');
console.log('- DISCORD_TOKEN');
console.log('- DISCORD_CLIENT_ID');
console.log('- DISCORD_CLIENT_SECRET');
console.log('- SESSION_SECRET');