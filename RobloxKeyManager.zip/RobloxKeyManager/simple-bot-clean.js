import { Client, GatewayIntentBits, SlashCommandBuilder, REST, Routes } from 'discord.js';

// Bot configuration - REPLACE ALL VALUES BELOW WITH YOUR ACTUAL CREDENTIALS
const token = 'PASTE_YOUR_DISCORD_BOT_TOKEN_HERE';
const clientId = 'PASTE_YOUR_CLIENT_ID_HERE';
const guildId = 'PASTE_YOUR_SERVER_ID_HERE';
const vipUsers = ['PASTE_YOUR_DISCORD_USER_ID_HERE']; // Your Discord user ID for VIP commands

if (!token || token.includes('PASTE_YOUR')) {
    console.error('❌ Please replace all PASTE_YOUR_* values with your actual Discord credentials');
    process.exit(1);
}

// Create Discord client
const client = new Client({
    intents: [GatewayIntentBits.Guilds]
});

// In-memory storage for keys and cooldowns
const keys = new Map();
const cooldowns = new Map();

function generateKeyCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const segments = [];
    for (let i = 0; i < 4; i++) {
        let segment = '';
        for (let j = 0; j < 4; j++) {
            segment += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        segments.push(segment);
    }
    return `Prism-${segments.join('-')}`;
}

function generateMonthKeyCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const segments = [];
    for (let i = 0; i < 4; i++) {
        let segment = '';
        for (let j = 0; j < 4; j++) {
            segment += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        segments.push(segment);
    }
    return `PrismVIP-${segments.join('-')}`;
}

function generateYearKeyCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const segments = [];
    for (let i = 0; i < 4; i++) {
        let segment = '';
        for (let j = 0; j < 4; j++) {
            segment += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        segments.push(segment);
    }
    return `PrismYear-${segments.join('-')}`;
}

function generateLifetimeKeyCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const segments = [];
    for (let i = 0; i < 4; i++) {
        let segment = '';
        for (let j = 0; j < 4; j++) {
            segment += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        segments.push(segment);
    }
    return `PrismLife-${segments.join('-')}`;
}

// Slash commands
const commands = [
    new SlashCommandBuilder()
        .setName('generate24key')
        .setDescription('Generate a 24-hour Prism executor key'),
    new SlashCommandBuilder()
        .setName('generate1mkey')
        .setDescription('Generate a 1-month VIP Prism executor key (VIP only)'),
    new SlashCommandBuilder()
        .setName('generateyearkey')
        .setDescription('Generate a 1-year VIP Prism executor key (VIP only)'),
    new SlashCommandBuilder()
        .setName('generatelifetimekey')
        .setDescription('Generate a lifetime VIP Prism executor key (VIP only)'),
    new SlashCommandBuilder()
        .setName('setup-logs')
        .setDescription('Set up Discord channel for bot logging (Admin only)')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel to send logs to')
                .setRequired(true))
];

// Register commands
const rest = new REST().setToken(token);

client.once('ready', async () => {
    console.log(`✅ Bot logged in as ${client.user.tag}`);
    
    try {
        if (guildId && !guildId.includes('PASTE_YOUR')) {
            console.log('🔄 Registering commands to server (instant)...');
            await rest.put(
                Routes.applicationGuildCommands(clientId, guildId),
                { body: commands }
            );
            console.log('✅ Server commands registered! Available immediately.');
        } else {
            console.log('🔄 Registering commands globally (takes up to 1 hour)...');
            await rest.put(
                Routes.applicationCommands(clientId),
                { body: commands }
            );
            console.log('✅ Global commands registered! May take up to 1 hour to appear.');
        }
        console.log('🚀 Bot is ready and online!');
    } catch (error) {
        console.error('❌ Error registering commands:', error);
    }
});

// Handle slash commands
client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    const { commandName, user } = interaction;

    try {
        if (commandName === 'generate24key') {
            // Check cooldown
            const cooldownKey = user.id;
            const now = Date.now();
            const cooldownTime = 24 * 60 * 60 * 1000; // 24 hours

            if (cooldowns.has(cooldownKey)) {
                const expirationTime = cooldowns.get(cooldownKey) + cooldownTime;
                if (now < expirationTime) {
                    const timeLeft = Math.ceil((expirationTime - now) / 1000 / 60 / 60);
                    await interaction.reply({
                        content: `⏰ You're on cooldown! You can generate another key in ${timeLeft} hours.`,
                        ephemeral: true
                    });
                    return;
                }
            }

            // Check for existing active key
            let existingKey = null;
            for (const [keyCode, keyData] of keys.entries()) {
                if (keyData.discordUserId === user.id && keyData.expiresAt > now) {
                    existingKey = { keyCode, ...keyData };
                    break;
                }
            }

            if (existingKey) {
                const timeLeft = Math.ceil((existingKey.expiresAt - now) / 1000 / 60 / 60);
                await interaction.reply({
                    content: `🔑 **Your existing 24-hour key:**\n\`\`\`${existingKey.keyCode}\`\`\`\n⏰ Expires in ${timeLeft} hours`,
                    ephemeral: true
                });
                return;
            }

            // Generate new key
            const keyCode = generateKeyCode();
            const expiresAt = now + cooldownTime;
            
            keys.set(keyCode, {
                discordUserId: user.id,
                createdAt: now,
                expiresAt: expiresAt,
                isActive: true
            });

            // Set cooldown
            cooldowns.set(cooldownKey, now);

            await interaction.reply({
                content: `✅ **24-Hour Key Generated Successfully!**\n\`\`\`${keyCode}\`\`\`\n⏰ Expires in 24 hours`,
                ephemeral: true
            });

        } else if (commandName === 'generate1mkey') {
            // Check if user is VIP
            if (!vipUsers.includes(user.id)) {
                await interaction.reply({
                    content: '❌ This command is only available to VIP users.',
                    ephemeral: true
                });
                return;
            }

            // Generate month key (no cooldown for VIP)
            const keyCode = generateMonthKeyCode();
            const expiresAt = now + (30 * 24 * 60 * 60 * 1000); // 30 days
            
            keys.set(keyCode, {
                discordUserId: user.id,
                createdAt: now,
                expiresAt: expiresAt,
                isActive: true,
                transferable: true
            });

            await interaction.reply({
                content: `✅ **VIP Month Key Generated!**\n\`\`\`${keyCode}\`\`\`\n⏰ Expires in 30 days\n🔄 This key is transferable`,
                ephemeral: true
            });

        } else if (commandName === 'generateyearkey') {
            if (!vipUsers.includes(user.id)) {
                await interaction.reply({
                    content: '❌ This command is only available to VIP users.',
                    ephemeral: true
                });
                return;
            }

            const keyCode = generateYearKeyCode();
            const expiresAt = now + (365 * 24 * 60 * 60 * 1000); // 365 days
            
            keys.set(keyCode, {
                discordUserId: user.id,
                createdAt: now,
                expiresAt: expiresAt,
                isActive: true,
                transferable: true
            });

            await interaction.reply({
                content: `✅ **VIP Year Key Generated!**\n\`\`\`${keyCode}\`\`\`\n⏰ Expires in 1 year\n🔄 This key is transferable`,
                ephemeral: true
            });

        } else if (commandName === 'generatelifetimekey') {
            if (!vipUsers.includes(user.id)) {
                await interaction.reply({
                    content: '❌ This command is only available to VIP users.',
                    ephemeral: true
                });
                return;
            }

            const keyCode = generateLifetimeKeyCode();
            const expiresAt = now + (100 * 365 * 24 * 60 * 60 * 1000); // 100 years (effectively lifetime)
            
            keys.set(keyCode, {
                discordUserId: user.id,
                createdAt: now,
                expiresAt: expiresAt,
                isActive: true,
                transferable: true
            });

            await interaction.reply({
                content: `✅ **VIP Lifetime Key Generated!**\n\`\`\`${keyCode}\`\`\`\n⏰ Never expires\n🔄 This key is transferable`,
                ephemeral: true
            });

        } else if (commandName === 'setup-logs') {
            const adminUsers = vipUsers; // VIP users are also admins
            
            if (!adminUsers.includes(user.id)) {
                await interaction.reply({
                    content: '❌ This command is only available to administrators.',
                    ephemeral: true
                });
                return;
            }

            const channel = interaction.options.getChannel('channel');
            
            await interaction.reply({
                content: `✅ **Logs channel set!**\nBot logs will be sent to ${channel}\n\n*Note: This is a simplified bot - full logging is available in the complete version.*`,
                ephemeral: true
            });
        }

    } catch (error) {
        console.error('Command error:', error);
        await interaction.reply({
            content: '❌ An error occurred while processing your command.',
            ephemeral: true
        });
    }
});

// Login
client.login(token);