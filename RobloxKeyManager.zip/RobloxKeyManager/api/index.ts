// Vercel serverless function entry point
import '../server/index';